$(document).ready(function(){

$(function(){ 
    	$("#la1").click(function(){ 
        	$("#menu1").slideToggle(); 
    	}); 
	}); 

$(function(){ 
    	$("#la2").click(function(){ 
        	$("#menu2").slideToggle(); 
    	}); 
	}); 
$(function(){ 
    	$("#la3").click(function(){ 
        	$("#menu3").slideToggle(); 
    	}); 
	}); 

$(function(){ 
    	$("#la4").click(function(){ 
        	$("#menu4").slideToggle(); 
    	}); 
	}); 

$(function(){ 
    	$("#la5").click(function(){ 
        	$("#menu5").slideToggle(); 
    	}); 
	}); 


});

